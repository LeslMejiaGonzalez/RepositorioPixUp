package org.gerdoc.pixup.negocio;

public interface Ejecutable
{
    void run( );
    void setFlag( boolean flag );
}
