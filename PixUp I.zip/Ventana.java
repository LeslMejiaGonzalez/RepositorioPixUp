public class Ventana {
    public void iniciar() {
        System.out.println("Modo ventana no implementado todavía.");
    }
}